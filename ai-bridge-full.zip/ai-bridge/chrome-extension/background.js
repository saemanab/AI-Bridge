// Service worker: talks to the local VS Code bridge on behalf of the AI Studio page.
importScripts("config.js");

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.type !== "bridge-get") return;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);

  fetch(`${BRIDGE_URL}${msg.route}`, {
    method: "GET",
    headers: { "X-AI-Bridge-Token": BRIDGE_TOKEN },
    cache: "no-store",
    signal: controller.signal
  })
    .then(async (response) => {
      const data = await response.json();
      if (!response.ok || !data.ok) {
        throw new Error(data.error || `Bridge returned HTTP ${response.status}`);
      }
      sendResponse({ ok: true, data });
    })
    .catch((error) => {
      const message = error.name === "AbortError"
        ? "Bridge did not respond. Check that VS Code is running."
        : (error.message === "Failed to fetch" ? "Cannot reach the VS Code bridge. Is VS Code running?" : error.message);
      sendResponse({ ok: false, error: message });
    })
    .finally(() => clearTimeout(timeoutId));

  return true; // keep the channel open for the async response
});
