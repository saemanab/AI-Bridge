(() => {
  const GROUP_ID = "ai-bridge-group";

  function isVisible(el) {
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  function findPrompt() {
    return (
      document.querySelector('textarea[placeholder*="Start typing a prompt"]') ||
      document.querySelector("ms-prompt-box textarea") ||
      [...document.querySelectorAll("textarea")].find(isVisible) ||
      [...document.querySelectorAll('[contenteditable="true"]')].find(isVisible) ||
      null
    );
  }

  function insertText(el, text) {
    el.focus();
    if (el.tagName === "TEXTAREA") {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set;
      const current = el.value;
      const sep = current && !current.endsWith("\n") ? "\n\n" : "";
      setter.call(el, current + sep + text);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      el.setSelectionRange(el.value.length, el.value.length);
      el.scrollTop = el.scrollHeight;
    } else {
      const sel = window.getSelection();
      sel.selectAllChildren(el);
      sel.collapseToEnd();
      document.execCommand("insertText", false, text);
    }
  }

  function bridgeGet(route) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage({ type: "bridge-get", route }, (res) => {
          if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
          if (!res || !res.ok) return reject(new Error((res && res.error) || "No response from extension."));
          resolve(res.data);
        });
      } catch (e) {
        reject(new Error("Extension was reloaded. Refresh this page."));
      }
    });
  }

  function flash(button, label, cls) {
    const original = button.dataset.label;
    button.textContent = label;
    button.classList.add(cls);
    setTimeout(() => {
      button.textContent = original;
      button.classList.remove(cls);
    }, 2500);
  }

  async function run(button, route, build) {
    const prompt = findPrompt();
    if (!prompt) return flash(button, "Prompt box not found", "ai-bridge-err");
    button.disabled = true;
    button.textContent = "Loading…";
    try {
      const data = await bridgeGet(route);
      insertText(prompt, build(data));
      button.disabled = false;
      flash(button, "Pasted ✓", "ai-bridge-ok");
    } catch (e) {
      button.disabled = false;
      flash(button, e.message.length > 40 ? "Error – see console" : e.message, "ai-bridge-err");
      console.error("[AI Bridge]", e);
    }
  }

  function makeButton(label, handler) {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = label;
    b.dataset.label = label;
    b.addEventListener("click", () => handler(b));
    return b;
  }

  function buildGroup() {
    const group = document.createElement("span");
    group.id = GROUP_ID;
    group.append(
      makeButton("Paste Project", (b) => run(b, "/api/project", (d) => d.bundle)),
      makeButton("Paste File", (b) =>
        run(b, "/api/active-file", (f) => {
          const lang = (f.languageId || "").replace(/[^a-zA-Z0-9_-]/g, "");
          return `File: ${f.filePath}\n\n\`\`\`${lang}\n${f.content}\n\`\`\``;
        })
      )
    );
    return group;
  }

  function findToolsButton() {
    return [...document.querySelectorAll("button")].find(
      (b) => /(^|\s)Tools$/.test(b.textContent.trim()) && isVisible(b)
    );
  }

  function ensureMounted() {
    let group = document.getElementById(GROUP_ID);
    if (!group) group = buildGroup();
    const tools = findToolsButton();
    if (tools) {
      if (group.previousElementSibling !== tools) {
        group.classList.remove("ai-bridge-floating");
        tools.insertAdjacentElement("afterend", group);
      }
    } else if (!group.isConnected) {
      group.classList.add("ai-bridge-floating");
      document.body.appendChild(group);
    }
  }

  let timer = null;
  new MutationObserver(() => {
    clearTimeout(timer);
    timer = setTimeout(ensureMounted, 300);
  }).observe(document.documentElement, { childList: true, subtree: true });
  ensureMounted();
})();
