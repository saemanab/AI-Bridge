const statusEl = document.getElementById("status");
const messageEl = document.getElementById("message");
const reconnectButton = document.getElementById("reconnect");
const copyProjectButton = document.getElementById("copyProject");
const copyActiveButton = document.getElementById("copyActive");

// Keep popup startup local and immediate: do not make a network request on load.
// The user can explicitly check the bridge, or use either copy action directly.
function setStatus(state, label) {
  statusEl.className = `status ${state}`;
  statusEl.replaceChildren();
  const dot = document.createElement("span");
  dot.className = "dot";
  statusEl.append(dot, document.createTextNode(` ${label}`));
}

function setBusy(button, busy, label) {
  button.disabled = busy;
  if (busy) {
    button.dataset.originalText = button.textContent;
    button.textContent = label;
  } else if (button.dataset.originalText) {
    button.textContent = button.dataset.originalText;
    delete button.dataset.originalText;
  }
}


// Clipboard write with a fallback for cases where the async API is blocked.
async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch (e) {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    if (!ok) throw new Error("Clipboard write was blocked by the browser.");
  }
}

async function bridgeGet(route) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 2500);

  try {
    const response = await fetch(`${BRIDGE_URL}${route}`, {
      method: "GET",
      headers: { "X-AI-Bridge-Token": BRIDGE_TOKEN },
      cache: "no-store",
      signal: controller.signal
    });
    const data = await response.json();
    if (!response.ok || !data.ok) {
      throw new Error(data.error || `Bridge returned HTTP ${response.status}`);
    }
    return data;
  } catch (error) {
    if (error.name === "AbortError") {
      throw new Error("Bridge did not respond within 2.5 seconds. Check that VS Code is running.");
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}

async function checkConnection() {
  setBusy(reconnectButton, true, "Checking…");
  messageEl.textContent = "Checking the local VS Code bridge…";
  try {
    await bridgeGet("/health");
    setStatus("online", "Connected");
    messageEl.textContent = "VS Code bridge is ready.";
  } catch (error) {
    setStatus("offline", "Offline");
    messageEl.textContent = error.message;
  } finally {
    setBusy(reconnectButton, false);
  }
}

reconnectButton.addEventListener("click", checkConnection);

copyActiveButton.addEventListener("click", async () => {
  setBusy(copyActiveButton, true, "Copying…");
  messageEl.textContent = "Reading active VS Code file…";
  try {
    const file = await bridgeGet("/api/active-file");
    const language = (file.languageId || "").replace(/[^a-zA-Z0-9_-]/g, "");
    const header = `File: ${file.filePath}\nLanguage: ${file.languageId}\nUnsaved changes: ${file.isDirty ? "Yes" : "No"}\n\n`;
    await copyText(header + `\`\`\`${language}\n${file.content}\n\`\`\``);
    setStatus("online", "Connected");
    messageEl.textContent = `Copied ${file.fileName}. Paste into Google AI Studio with Ctrl+V.`;
  } catch (error) {
    setStatus("offline", "Offline");
    messageEl.textContent = error.message;
  } finally {
    setBusy(copyActiveButton, false);
  }
});

copyProjectButton.addEventListener("click", async () => {
  setBusy(copyProjectButton, true, "Collecting…");
  messageEl.textContent = "Collecting eligible project source files…";
  try {
    const project = await bridgeGet("/api/project");
    await copyText(project.bundle);
    setStatus("online", "Connected");
    messageEl.textContent = `Copied ${project.fileCount} files (${Math.round(project.totalBytes / 1024)} KB) from ${project.projectName}.${project.truncated ? " WARNING: bundle may be incomplete." : ""} Paste into AI Studio with Ctrl+V.`;
  } catch (error) {
    setStatus("offline", "Offline");
    messageEl.textContent = error.message;
  } finally {
    setBusy(copyProjectButton, false);
  }
});

// No automatic localhost fetch here. Popup is interactive immediately after opening.
setStatus("offline", "Not checked");
messageEl.textContent = "Ready. Click Save & Reconnect to check VS Code.";
